// create express route(mini express app)
const exp = require("express");
const productApp = exp.Router();



module.exports = productApp;
